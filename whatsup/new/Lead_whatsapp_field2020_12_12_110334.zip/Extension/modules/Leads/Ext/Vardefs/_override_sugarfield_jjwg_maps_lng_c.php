<?php
 // created: 2020-11-09 15:27:10
$dictionary['Lead']['fields']['jjwg_maps_lng_c']['inline_edit']=1;

 ?>