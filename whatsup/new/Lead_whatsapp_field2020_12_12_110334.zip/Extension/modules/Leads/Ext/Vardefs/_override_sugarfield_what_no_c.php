<?php
 // created: 2020-12-08 20:38:35
$dictionary['Lead']['fields']['what_no_c']['inline_edit']='1';
$dictionary['Lead']['fields']['what_no_c']['labelValue']='what no';

 ?>