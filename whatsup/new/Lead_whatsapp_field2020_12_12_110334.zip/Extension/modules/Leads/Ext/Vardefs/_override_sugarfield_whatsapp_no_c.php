<?php
 // created: 2020-12-08 19:42:10
$dictionary['Lead']['fields']['whatsapp_no_c']['inline_edit']='1';
$dictionary['Lead']['fields']['whatsapp_no_c']['labelValue']='Whatsapp No';

 ?>