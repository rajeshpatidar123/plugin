<?php
 // created: 2020-12-12 10:57:00
$dictionary['Lead']['fields']['whatsapp_mobile_no_c']['inline_edit']='1';
$dictionary['Lead']['fields']['whatsapp_mobile_no_c']['labelValue']='Whatsapp Mobile';

 ?>