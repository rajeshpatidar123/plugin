<?php
 // created: 2020-11-09 15:27:18
$dictionary['Lead']['fields']['jjwg_maps_address_c']['inline_edit']=1;

 ?>