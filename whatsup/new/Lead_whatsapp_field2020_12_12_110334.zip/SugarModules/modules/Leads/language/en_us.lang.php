<?php 
 // created: 2020-12-12 11:03:31
$mod_strings['LBL_WHATSAPP_NO '] = 'Whatsapp No';
$mod_strings['LBL_EDITVIEW_PANEL1'] = 'undefined 1';
$mod_strings['LBL_WHATSAPP_NO_'] = 'Whatsapp No.';
$mod_strings['LBL_WHATSAPP_MOBILE_NO'] = 'Whatsapp Mobile';

?>
