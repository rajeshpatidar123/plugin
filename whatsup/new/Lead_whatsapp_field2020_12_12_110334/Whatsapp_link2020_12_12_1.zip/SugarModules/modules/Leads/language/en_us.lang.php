<?php 
 // created: 2020-12-12 11:03:31
$mod_strings['LBL_WHATSAPP_MOBILE_NO'] = 'Whatsapp Mobile No';

?>
