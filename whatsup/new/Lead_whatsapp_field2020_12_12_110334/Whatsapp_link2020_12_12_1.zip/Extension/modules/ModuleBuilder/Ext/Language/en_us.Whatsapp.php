<?php
$mod_strings['fieldTypes']['Whatsapp'] = 'Whatsapp Link';