<?php
// created: 2020-11-21 20:10:00
$dictionary["CU_Custom_Services_Contract"]["fields"]["cu_custom_services_contract_aos_contracts"] = array (
  'name' => 'cu_custom_services_contract_aos_contracts',
  'type' => 'link',
  'relationship' => 'cu_custom_services_contract_aos_contracts',
  'source' => 'non-db',
  'module' => 'AOS_Contracts',
  'bean_name' => 'AOS_Contracts',
  'side' => 'right',
  'vname' => 'LBL_CU_CUSTOM_SERVICES_CONTRACT_AOS_CONTRACTS_FROM_AOS_CONTRACTS_TITLE',
);
