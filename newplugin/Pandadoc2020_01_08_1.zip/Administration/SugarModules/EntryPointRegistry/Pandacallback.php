<?php
  $entry_point_registry['Pandacallback'] = array(
      'file' => 'custom/modules/Administration/Pandacallback.php',
      'auth' => true,
  );

 