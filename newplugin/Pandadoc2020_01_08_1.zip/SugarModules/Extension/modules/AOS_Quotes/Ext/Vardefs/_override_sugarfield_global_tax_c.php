<?php
 // created: 2020-11-27 21:18:34
$dictionary['AOS_Quotes']['fields']['global_tax_c']['inline_edit']='1';
$dictionary['AOS_Quotes']['fields']['global_tax_c']['labelValue']='Global Tax';

 ?>