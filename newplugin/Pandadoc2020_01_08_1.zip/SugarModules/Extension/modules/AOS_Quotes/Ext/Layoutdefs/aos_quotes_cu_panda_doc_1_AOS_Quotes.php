<?php
 // created: 2020-11-19 20:11:03
$layout_defs["AOS_Quotes"]["subpanel_setup"]['aos_quotes_cu_panda_doc_1'] = array (
  'order' => 100,
  'module' => 'CU_Panda_Doc',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_AOS_QUOTES_CU_PANDA_DOC_1_FROM_CU_PANDA_DOC_TITLE',
  'get_subpanel_data' => 'aos_quotes_cu_panda_doc_1',
  'top_buttons' => 
  array (
    0 => 
    array (
      'widget_class' => 'SubPanelTopButtonQuickCreate',
    ),
    1 => 
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
