<?php
 // created: 2020-11-27 12:27:50
$dictionary['AOS_Contracts']['fields']['global_tax_c']['inline_edit']='1';
$dictionary['AOS_Contracts']['fields']['global_tax_c']['labelValue']='Global Tax';

 ?>