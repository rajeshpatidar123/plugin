<?php 
 // created: 2020-11-20 16:37:43
$mod_strings['LBL_AOS_QUOTES_CU_PANDA_DOC_1_FROM_CU_PANDA_DOC_TITLE'] = 'Panda Doc';
$mod_strings['LBL_GLOBAL_TAX'] = 'Global Tax';
$mod_strings['LBL_GLOBAL_TAX_C'] = 'Global Tax';

?>
