<?php 
 // created: 2020-11-28 10:34:37
$mod_strings['LBL_CU_PANDA_DOC_AOS_CONTRACTS_FROM_CU_PANDA_DOC_TITLE'] = 'Panda Doc';
$mod_strings['LBL_GLOBAL_TAX'] = 'Global Tax';

?>
