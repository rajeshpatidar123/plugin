<?php 
$app_list_strings['global_vat_list'] = array (
  '0.0' => '0%',
  '21.0' => '21%',
);