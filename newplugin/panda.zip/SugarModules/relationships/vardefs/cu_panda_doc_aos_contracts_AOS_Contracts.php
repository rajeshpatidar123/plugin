<?php
// created: 2020-10-21 12:04:46
$dictionary["AOS_Contracts"]["fields"]["cu_panda_doc_aos_contracts"] = array (
  'name' => 'cu_panda_doc_aos_contracts',
  'type' => 'link',
  'relationship' => 'cu_panda_doc_aos_contracts',
  'source' => 'non-db',
  'module' => 'CU_Panda_Doc',
  'bean_name' => 'CU_Panda_Doc',
  'side' => 'right',
  'vname' => 'LBL_CU_PANDA_DOC_AOS_CONTRACTS_FROM_CU_PANDA_DOC_TITLE',
);
