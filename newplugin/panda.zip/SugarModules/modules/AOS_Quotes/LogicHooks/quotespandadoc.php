<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


 class class_logichook_quotes
     {
         function apipandadoc($bean, $event, $arguments)
         {
         
   //        $group=$_REQUEST['group_name'];
         
   //          $id =$bean->id;
   //           $bean->save();

   //      function encode_arr($group) {
   //         return base64_encode(serialize($group));
   //      }
   //      $GroupName1=encode_arr($group);

   // $url="index.php?entryPoint=QuotePandaredirect&group=".$GroupName1."&QuoteId=".$id."";
   //        SugarApplication::redirect($url);

         }
     }
?>
