<?php
if(!defined('sugarEntry') || !sugarEntry) die('Not A Valid Entry Point');


 class class_logichook
     {
         function apipandadoc($bean, $event, $arguments)
         {
         
//           global $sugar_config;
         
//           $DocumentId=$sugar_config['DocumentId'];
//           $group=$_REQUEST['group_name'];
         
//             $id =$bean->id;
//              $bean->save();

//         function encode_arr($group) {
//            return base64_encode(serialize($group));
//         }
//         $GroupName1=encode_arr($group);

//    $url="index.php?entryPoint=Pandaredirect&group=".$GroupName1."&ContractId=".$id."&DocumentId=".$DocumentId."";
//           SugarApplication::redirect($url);
// exit();

         }
     }
?>
