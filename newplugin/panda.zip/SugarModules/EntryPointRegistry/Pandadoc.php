<?php
  $entry_point_registry['Pandadoc'] = array(
      'file' => 'custom/modules/CU_Panda_Doc/Pandadoc.php',
      'auth' => true,
  );

 