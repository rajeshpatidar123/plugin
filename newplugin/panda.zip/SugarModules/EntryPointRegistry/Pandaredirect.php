<?php
  $entry_point_registry['Pandaredirect'] = array(
      'file' => 'custom/modules/AOS_Contracts/Pandaredirect.php',
      'auth' => true,
  );

 