<?php
  $entry_point_registry['QuotePandaredirect'] = array(
      'file' => 'custom/modules/AOS_Quotes/QuotePandaredirect.php',
      'auth' => true,
  );

 