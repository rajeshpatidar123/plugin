<?php
// created: 2020-11-19 20:11:03
$dictionary["AOS_Quotes"]["fields"]["aos_quotes_cu_panda_doc_1"] = array (
  'name' => 'aos_quotes_cu_panda_doc_1',
  'type' => 'link',
  'relationship' => 'aos_quotes_cu_panda_doc_1',
  'source' => 'non-db',
  'module' => 'CU_Panda_Doc',
  'bean_name' => 'CU_Panda_Doc',
  'side' => 'right',
  'vname' => 'LBL_AOS_QUOTES_CU_PANDA_DOC_1_FROM_CU_PANDA_DOC_TITLE',
);
