<?php
 
	$mod_strings['LBL_LINK_PANDA_NAME'] = 'Panda Doc Configuration';
    $mod_strings['LBL_LINK_PANDA_DESCRIPTION'] = 'SuiteCRM to Panda Doc sharing document';
    $mod_strings['LBL_SECTION_PANDA_HEADER'] = 'Panda Doc';
    $mod_strings['LBL_SECTION_PANDA_DESCRIPTION'] = '';

    $mod_strings['LBL_PANDA_APP_NAME'] = 'App Name';
	$mod_strings['LBL_PANDA_CLIENT_ID'] = 'Client ID';
	$mod_strings['LBL_PANDA_APP_SECRETE'] = 'App Secrete';
	$mod_strings['LBL_PANDA_REDIRECT_URL'] = 'Redirect URL';
	$mod_strings['LBL_AUTHENTICATION_SETTINGS'] = 'Panda Authentication Information';
	$mod_strings['LBL_DocumentId'] = 'Contract Template ID';
	$mod_strings['LBL_QouteDocumentId']= 'Qoute Template ID';
	$mod_strings['LBL_user_first_name']= 'User First Name';
	$mod_strings['LBL_user_last_name']= 'User Last Name';
	$mod_strings['LBL_user_email']= 'User Email';
	$mod_strings['LBL_sendbox_key']= 'Sendbox/Production API-Key';