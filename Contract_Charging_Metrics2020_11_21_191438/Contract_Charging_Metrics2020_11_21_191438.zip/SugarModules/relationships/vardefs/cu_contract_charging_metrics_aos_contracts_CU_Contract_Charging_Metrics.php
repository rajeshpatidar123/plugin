<?php
// created: 2020-11-21 19:14:38
$dictionary["CU_Contract_Charging_Metrics"]["fields"]["cu_contract_charging_metrics_aos_contracts"] = array (
  'name' => 'cu_contract_charging_metrics_aos_contracts',
  'type' => 'link',
  'relationship' => 'cu_contract_charging_metrics_aos_contracts',
  'source' => 'non-db',
  'module' => 'AOS_Contracts',
  'bean_name' => 'AOS_Contracts',
  'side' => 'right',
  'vname' => 'LBL_CU_CONTRACT_CHARGING_METRICS_AOS_CONTRACTS_FROM_AOS_CONTRACTS_TITLE',
);
